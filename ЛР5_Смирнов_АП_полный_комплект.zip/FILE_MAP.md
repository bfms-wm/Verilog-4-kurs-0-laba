# Соответствие отчета и файлов проекта

Все листинги в отчете приведены полностью. Номер листинга, файл и модуль должны совпадать с таблицей ниже.

| Раздел отчета | Листинг | Файл в архиве | Модуль или содержимое | Назначение |
| --- | --- | --- | --- | --- |
| 8.1.1 | 1 | `src/t_ff.v` | `t_ff` | Один T-триггер, хранение одного разряда состояния |
| 8.1.2-8.1.4 | 2 | `src/counter_structural.v` | `counter_structural` | Структурный счетчик; `MODE=0` Айкен вверх, `MODE=1` Грей вниз, `MODE=2` реверсивный Грей |
| 8.2.1 | 3 | `src/counter_behavioral.v` | `counter_beh_ternary` | Поведенческое описание с тернарным оператором |
| 8.2.2 | 4 | `src/counter_behavioral.v` | `counter_beh_case` | Поведенческое описание с `case` |
| 8.2.3 | 5 | `src/counter_behavioral.v` | `counter_beh_if` | Поведенческое описание с `if` |
| 8.2.4 | 6 | `src/counter_behavioral.v` | `counter_beh_function` | Поведенческое описание через функцию следующего состояния |
| 8.3 | 7 | `tb/tb_all.v` | `tb_all` | Самопроверяющийся испытательный стенд всех вариантов |
| 8.3 | 8 | `sim/run_sim.do` | сценарий ModelSim | Компиляция, запуск, добавление сигналов Wave |
| 9.2.1 | 9 | `src/board_support.v` | `clock_enable_divider`, `bit_display_driver` | Делители разрешающих импульсов и драйвер индикаторов |
| 9.1 и 9.2.1 | 10 | `src/tops.v` | `synth_top`, `board_top` | Верхние уровни проектов MAX II и Cyclone IV |

## Файлы Quartus

| Раздел отчета | Файл | Что задает |
| --- | --- | --- |
| 9.1 | `quartus/maxii/lab5_maxii.qpf` | Проект MAX II, открывать в Quartus |
| 9.1 | `quartus/maxii/lab5_maxii.qsf` | EPM240T100C5, `synth_top`, список Verilog-файлов |
| 9.1 | `quartus/maxii/lab5_maxii.sdc` | Ограничение тактового сигнала |
| 9.1 | `quartus/maxii/output_files/lab5_maxii.pof` | Файл программирования MAX II |
| 9.2 | `quartus/cycloneiv/lab5_cycloneiv.qpf` | Проект Cyclone IV, открывать в Quartus |
| 9.2 | `quartus/cycloneiv/lab5_cycloneiv.qsf` | EP4CE10E22C8, `board_top`, назначения выводов |
| 9.2 | `quartus/cycloneiv/lab5_cycloneiv.sdc` | Ограничение тактового сигнала |
| 9.2 | `quartus/cycloneiv/output_files/lab5_cycloneiv.sof` | Файл прошивки Cyclone IV |

## Важное различие верхних уровней

`synth_top` нужен для чистого синтеза логики счетчика Айкена на MAX II. `board_top` нужен для платы Cyclone IV: он добавляет делители частоты, кнопку направления, светодиоды и семисегментную индикацию. Поэтому ресурсы и предупреждения двух проектов отличаются.
