transcript on
# Отчет: раздел 8.3, листинг 8.
# Запускать из каталога sim командой: do run_sim.do
if {[file exists work]} {vdel -lib work -all}
vlib work
vmap work work
vlog -work work ../src/t_ff.v
vlog -work work ../src/counter_structural.v
vlog -work work ../src/counter_behavioral.v
vlog -work work ../tb/tb_all.v
vsim -voptargs=+acc work.tb_all
add wave -divider {Inputs}
add wave sim:/tb_all/clock
add wave sim:/tb_all/enable
add wave sim:/tb_all/dir
add wave -divider {Structural}
add wave -radix binary sim:/tb_all/s_aiken
add wave -radix binary sim:/tb_all/s_gray_down
add wave -radix binary sim:/tb_all/s_reverse
add wave -divider {Behavioral function}
add wave -radix binary sim:/tb_all/f_aiken
add wave -radix binary sim:/tb_all/f_gray_down
add wave -radix binary sim:/tb_all/f_reverse
run -all
wave zoom full
