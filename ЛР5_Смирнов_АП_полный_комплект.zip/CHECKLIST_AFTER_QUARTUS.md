# Что добавить в отчет после запуска программ

Перед началом распакуйте проект в каталог без русских букв, например `C:\lab5_smirnov`.

## ModelSim или Questa

- Рисунок 2: окно Transcript после `do run_sim.do`; должна быть видна строка `PASS: all structural and behavioral variants are correct`.
- Рисунок 3: окно Wave после `wave zoom full`; должны быть видны `clock`, `enable`, `dir`, `s_aiken`, `s_gray_down`, `s_reverse`, `f_aiken`, `f_gray_down`, `f_reverse`.

## Quartus MAX II

- Рисунок 4: `Processing -> Compilation Report -> Flow Summary` проекта `lab5_maxii`.
- Рисунок 5: `Tools -> Netlist Viewers -> RTL Viewer` проекта `lab5_maxii`.

## Quartus Cyclone IV

- Рисунок 6: `Processing -> Compilation Report -> Flow Summary` проекта `lab5_cycloneiv`.
- Рисунок 7: `Tools -> Netlist Viewers -> RTL Viewer` проекта `lab5_cycloneiv`.
- Рисунок 8: `Assignments -> Pin Planner`; должны быть видны имена сигналов и номера выводов.
- Рисунок 9: `Tools -> Programmer`; должен быть добавлен `lab5_cycloneiv.sof`. Без платы допустимо оставить место незаполненным до лаборатории.

## Лабораторная плата

- Рисунок 10: фотография счета вверх при отпущенной `dir_button`.
- Рисунок 11: фотография счета вниз при нажатой `dir_button`.
- Рисунок 12: фотография или серия фотографий после смены направления.
- До прошивки обязательно сверить распиновку QSF со схемой конкретной платы.

## Word

Замените серые поля-заглушки изображениями, не удаляя подписи. Затем нажмите `Ctrl+A`, `F9`, выберите обновление всей таблицы содержания и сохраните DOCX и PDF.
