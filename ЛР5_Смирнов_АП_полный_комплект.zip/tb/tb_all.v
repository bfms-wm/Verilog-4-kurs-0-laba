`timescale 1ns/1ps

// Отчет: раздел 8.3, листинг 7.
// Самопроверяющийся стенд для структурного и четырех поведенческих описаний.

module tb_all;
    reg clock = 1'b0;
    reg enable = 1'b1;
    reg dir = 1'b0;
    integer errors = 0;
    integer cycle;
    reg [3:0] expected_aiken = 4'h0;
    reg [3:0] expected_gray_down = 4'h0;
    reg [3:0] expected_reverse = 4'h0;

    wire [3:0] s_aiken, s_gray_down, s_reverse;
    wire [3:0] t_aiken, c_aiken, i_aiken, f_aiken;
    wire [3:0] t_gray_down, c_gray_down, i_gray_down, f_gray_down;
    wire [3:0] t_reverse, c_reverse, i_reverse, f_reverse;

    counter_structural #(.MODE(0)) u_s_aiken(clock, enable, dir, s_aiken);
    counter_structural #(.MODE(1)) u_s_gray_down(clock, enable, dir, s_gray_down);
    counter_structural #(.MODE(2)) u_s_reverse(clock, enable, dir, s_reverse);

    counter_beh_ternary #(.MODE(0)) u_t_aiken(clock, enable, dir, t_aiken);
    counter_beh_case #(.MODE(0)) u_c_aiken(clock, enable, dir, c_aiken);
    counter_beh_if #(.MODE(0)) u_i_aiken(clock, enable, dir, i_aiken);
    counter_beh_function #(.MODE(0)) u_f_aiken(clock, enable, dir, f_aiken);

    counter_beh_ternary #(.MODE(1)) u_t_gray_down(clock, enable, dir, t_gray_down);
    counter_beh_case #(.MODE(1)) u_c_gray_down(clock, enable, dir, c_gray_down);
    counter_beh_if #(.MODE(1)) u_i_gray_down(clock, enable, dir, i_gray_down);
    counter_beh_function #(.MODE(1)) u_f_gray_down(clock, enable, dir, f_gray_down);

    counter_beh_ternary #(.MODE(2)) u_t_reverse(clock, enable, dir, t_reverse);
    counter_beh_case #(.MODE(2)) u_c_reverse(clock, enable, dir, c_reverse);
    counter_beh_if #(.MODE(2)) u_i_reverse(clock, enable, dir, i_reverse);
    counter_beh_function #(.MODE(2)) u_f_reverse(clock, enable, dir, f_reverse);

    always #5 clock = ~clock;

    function [3:0] next_aiken;
        input [3:0] state;
        begin
            case (state)
                4'h0: next_aiken = 4'h1;
                4'h1: next_aiken = 4'h2;
                4'h2: next_aiken = 4'h3;
                4'h3: next_aiken = 4'h4;
                4'h4: next_aiken = 4'hB;
                4'hB: next_aiken = 4'hC;
                4'hC: next_aiken = 4'hD;
                4'hD: next_aiken = 4'hE;
                4'hE: next_aiken = 4'hF;
                4'hF: next_aiken = 4'h0;
                default: next_aiken = 4'h0;
            endcase
        end
    endfunction

    function [3:0] next_gray_down;
        input [3:0] state;
        begin
            case (state)
                4'h0: next_gray_down = 4'h8;
                4'h8: next_gray_down = 4'h9;
                4'h9: next_gray_down = 4'hB;
                4'hB: next_gray_down = 4'hA;
                4'hA: next_gray_down = 4'hE;
                4'hE: next_gray_down = 4'hF;
                4'hF: next_gray_down = 4'hD;
                4'hD: next_gray_down = 4'hC;
                4'hC: next_gray_down = 4'h4;
                4'h4: next_gray_down = 4'h5;
                4'h5: next_gray_down = 4'h7;
                4'h7: next_gray_down = 4'h6;
                4'h6: next_gray_down = 4'h2;
                4'h2: next_gray_down = 4'h3;
                4'h3: next_gray_down = 4'h1;
                default: next_gray_down = 4'h0;
            endcase
        end
    endfunction

    function [3:0] next_gray_up;
        input [3:0] state;
        begin
            case (state)
                4'h0: next_gray_up = 4'h1;
                4'h1: next_gray_up = 4'h3;
                4'h3: next_gray_up = 4'h2;
                4'h2: next_gray_up = 4'h6;
                4'h6: next_gray_up = 4'h7;
                4'h7: next_gray_up = 4'h5;
                4'h5: next_gray_up = 4'h4;
                4'h4: next_gray_up = 4'hC;
                4'hC: next_gray_up = 4'hD;
                4'hD: next_gray_up = 4'hF;
                4'hF: next_gray_up = 4'hE;
                4'hE: next_gray_up = 4'hA;
                4'hA: next_gray_up = 4'hB;
                4'hB: next_gray_up = 4'h9;
                4'h9: next_gray_up = 4'h8;
                default: next_gray_up = 4'h0;
            endcase
        end
    endfunction

    task check_all;
        begin
            if ((s_aiken !== expected_aiken) ||
                (t_aiken !== expected_aiken) ||
                (c_aiken !== expected_aiken) ||
                (i_aiken !== expected_aiken) ||
                (f_aiken !== expected_aiken)) begin
                $display("ERROR Aiken cycle=%0d expected=%h", cycle, expected_aiken);
                errors = errors + 1;
            end
            if ((s_gray_down !== expected_gray_down) ||
                (t_gray_down !== expected_gray_down) ||
                (c_gray_down !== expected_gray_down) ||
                (i_gray_down !== expected_gray_down) ||
                (f_gray_down !== expected_gray_down)) begin
                $display("ERROR Gray down cycle=%0d expected=%h", cycle, expected_gray_down);
                errors = errors + 1;
            end
            if ((s_reverse !== expected_reverse) ||
                (t_reverse !== expected_reverse) ||
                (c_reverse !== expected_reverse) ||
                (i_reverse !== expected_reverse) ||
                (f_reverse !== expected_reverse)) begin
                $display("ERROR reverse cycle=%0d dir=%b expected=%h", cycle, dir, expected_reverse);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        $dumpfile("lab5.vcd");
        $dumpvars(0, tb_all);

        for (cycle = 1; cycle <= 20; cycle = cycle + 1) begin
            @(posedge clock);
            expected_aiken = next_aiken(expected_aiken);
            expected_gray_down = next_gray_down(expected_gray_down);
            expected_reverse = next_gray_up(expected_reverse);
            #1 check_all;
        end

        dir = 1'b1;
        for (cycle = 21; cycle <= 40; cycle = cycle + 1) begin
            @(posedge clock);
            expected_aiken = next_aiken(expected_aiken);
            expected_gray_down = next_gray_down(expected_gray_down);
            expected_reverse = next_gray_down(expected_reverse);
            #1 check_all;
        end

        enable = 1'b0;
        @(posedge clock);
        #1 check_all;

        if (errors == 0)
            $display("PASS: all structural and behavioral variants are correct");
        else
            $display("FAIL: %0d mismatches", errors);
        $finish;
    end
endmodule
