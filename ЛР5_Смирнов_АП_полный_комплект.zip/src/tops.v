`timescale 1ns/1ps

// Отчет: разделы 9.1 и 9.2.1, листинг 10.
// synth_top - верхний уровень проекта MAX II.
// board_top - верхний уровень проекта Cyclone IV и лабораторной платы.
// Верхний уровень для получения отчета синтеза MAX II.
module synth_top (
    input  wire       clock,
    input  wire       dir,
    output wire [3:0] q
);
    counter_structural #(.MODE(0)) dut (
        .clock  (clock),
        .enable (1'b1),
        .dir    (dir),
        .q      (q)
    );
endmodule


// Верхний уровень для платы Cyclone IV из примера одногруппника.
module board_top (
    input  wire       clock,
    input  wire       dir_button,
    output wire [3:0] leds,
    output wire [7:0] indicator_select,
    output wire [7:0] segments
);
    wire count_enable;
    wire scan_enable;
    wire [3:0] counter_value;
    wire dir;

    // Кнопки платы активны низким уровнем.
    assign dir = ~dir_button;

    clock_enable_divider #(.DIVISOR(25000000)) count_divider (
        .clock  (clock),
        .enable (count_enable)
    );

    clock_enable_divider #(.DIVISOR(5000)) scan_divider (
        .clock  (clock),
        .enable (scan_enable)
    );

    counter_beh_function #(.MODE(2)) counter (
        .clock  (clock),
        .enable (count_enable),
        .dir    (dir),
        .q      (counter_value)
    );

    assign leds = counter_value;

    bit_display_driver display (
        .clock            (clock),
        .scan_enable      (scan_enable),
        .value            (counter_value),
        .indicator_select (indicator_select),
        .segments         (segments)
    );
endmodule
