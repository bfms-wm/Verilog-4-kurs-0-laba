`timescale 1ns/1ps

// Отчет: раздел 9.2.1, листинг 9.
// Вспомогательные модули платы: делители разрешающих импульсов и индикация.

module clock_enable_divider #(
    parameter integer DIVISOR = 25000000
) (
    input  wire clock,
    output reg  enable = 1'b0
);
    reg [31:0] count = 32'd0;

    always @(posedge clock) begin
        if (count == DIVISOR - 1) begin
            count  <= 32'd0;
            enable <= 1'b1;
        end else begin
            count  <= count + 1'b1;
            enable <= 1'b0;
        end
    end
endmodule


module bit_display_driver (
    input  wire       clock,
    input  wire       scan_enable,
    input  wire [3:0] value,
    output reg  [7:0] indicator_select,
    output reg  [7:0] segments
);
    reg [1:0] scan = 2'b00;
    reg current_bit;

    always @(posedge clock) begin
        if (scan_enable)
            scan <= scan + 1'b1;
    end

    always @(*) begin
        indicator_select = 8'b1111_1111;
        current_bit = 1'b0;
        case (scan)
            2'd0: begin indicator_select = 8'b1111_1110; current_bit = value[3]; end
            2'd1: begin indicator_select = 8'b1111_1101; current_bit = value[2]; end
            2'd2: begin indicator_select = 8'b1111_1011; current_bit = value[1]; end
            default: begin indicator_select = 8'b1111_0111; current_bit = value[0]; end
        endcase

        case (current_bit)
            1'b0: segments = 8'b1100_0000;
            1'b1: segments = 8'b1111_1001;
            default: segments = 8'b1111_1111;
        endcase
    end
endmodule
