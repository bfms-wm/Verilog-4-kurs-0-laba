`timescale 1ns/1ps

// Отчет: раздел 8.1.1, листинг 1.
// Модуль t_ff - один T-триггер с синхронным разрешением enable.

module t_ff (
    input  wire clock,
    input  wire enable,
    input  wire t,
    output reg  q = 1'b0
);
    always @(posedge clock) begin
        if (enable && t)
            q <= ~q;
    end
endmodule
