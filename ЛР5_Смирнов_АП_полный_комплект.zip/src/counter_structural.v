`timescale 1ns/1ps

// Отчет: разделы 8.1.2-8.1.4, листинг 2.
// Модуль counter_structural - структурный счетчик на четырех t_ff.
// MODE = 0: суммирование, код Айкена 2421.
// MODE = 1: вычитание, отраженный код Грея.
// MODE = 2: реверсивный счет в коде Грея; dir=0 вверх, dir=1 вниз.
module counter_structural #(
    parameter integer MODE = 0
) (
    input  wire       clock,
    input  wire       enable,
    input  wire       dir,
    output wire [3:0] q
);
    wire parity;
    wire [3:0] t_aiken_up;
    wire [3:0] t_gray_down;
    wire [3:0] t_gray_up;
    wire [3:0] t_selected;

    assign parity = q[3] ^ q[2] ^ q[1] ^ q[0];

    // Минимизированные функции возбуждения T-триггеров для кода Айкена.
    assign t_aiken_up[0] = 1'b1;
    assign t_aiken_up[1] = q[0] | (~q[3] & q[2]);
    assign t_aiken_up[2] = (q[1] & q[0]) | (~q[3] & q[2]);
    assign t_aiken_up[3] = (q[2] & q[1] & q[0]) | (~q[3] & q[2]);

    // Счет вниз в отраженном коде Грея.
    assign t_gray_down[0] = parity;
    assign t_gray_down[1] = q[0] & (q[3] ^ q[2] ^ q[1]);
    assign t_gray_down[2] = ~q[0] & q[1] & (q[3] ^ q[2]);
    assign t_gray_down[3] = ~q[1] & ~q[0] & ~(q[3] ^ q[2]);

    // Счет вверх в отраженном коде Грея.
    assign t_gray_up[0] = ~parity;
    assign t_gray_up[1] = q[0] & ~(q[3] ^ q[2] ^ q[1]);
    assign t_gray_up[2] = ~q[0] & q[1] & ~(q[3] ^ q[2]);
    assign t_gray_up[3] = ~q[1] & ~q[0] & (q[3] ^ q[2]);

    generate
        if (MODE == 0) begin : select_aiken_up
            assign t_selected = t_aiken_up;
        end else if (MODE == 1) begin : select_gray_down
            assign t_selected = t_gray_down;
        end else begin : select_gray_reversible
            assign t_selected = dir ? t_gray_down : t_gray_up;
        end
    endgenerate

    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : make_t_ff
            t_ff bit_ff (
                .clock  (clock),
                .enable (enable),
                .t      (t_selected[i]),
                .q      (q[i])
            );
        end
    endgenerate
endmodule
