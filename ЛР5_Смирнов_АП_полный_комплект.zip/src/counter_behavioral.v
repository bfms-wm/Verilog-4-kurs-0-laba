`timescale 1ns/1ps

// Отчет: раздел 8.2, листинги 3-6.
// counter_beh_ternary  - раздел 8.2.1, тернарный оператор.
// counter_beh_case     - раздел 8.2.2, оператор case.
// counter_beh_if       - раздел 8.2.3, оператор if.
// counter_beh_function - раздел 8.2.4, функция следующего состояния.

// Четыре самостоятельных поведенческих описания одного устройства.
// MODE = 0: Айкен вверх; MODE = 1: Грей вниз;
// MODE = 2: Грей вверх/вниз по входу dir.

module counter_beh_ternary #(
    parameter integer MODE = 0
) (
    input wire clock,
    input wire enable,
    input wire dir,
    output wire [3:0] q
);
    wire [3:0] next_aiken;
    wire [3:0] next_gray_down;
    wire [3:0] next_gray_up;
    wire [3:0] next_state;
    wire [3:0] t;

    assign next_aiken =
        (q == 4'b0000) ? 4'b0001 :
        (q == 4'b0001) ? 4'b0010 :
        (q == 4'b0010) ? 4'b0011 :
        (q == 4'b0011) ? 4'b0100 :
        (q == 4'b0100) ? 4'b1011 :
        (q == 4'b1011) ? 4'b1100 :
        (q == 4'b1100) ? 4'b1101 :
        (q == 4'b1101) ? 4'b1110 :
        (q == 4'b1110) ? 4'b1111 :
        (q == 4'b1111) ? 4'b0000 : 4'b0000;

    assign next_gray_down =
        (q == 4'b0000) ? 4'b1000 :
        (q == 4'b0001) ? 4'b0000 :
        (q == 4'b0011) ? 4'b0001 :
        (q == 4'b0010) ? 4'b0011 :
        (q == 4'b0110) ? 4'b0010 :
        (q == 4'b0111) ? 4'b0110 :
        (q == 4'b0101) ? 4'b0111 :
        (q == 4'b0100) ? 4'b0101 :
        (q == 4'b1100) ? 4'b0100 :
        (q == 4'b1101) ? 4'b1100 :
        (q == 4'b1111) ? 4'b1101 :
        (q == 4'b1110) ? 4'b1111 :
        (q == 4'b1010) ? 4'b1110 :
        (q == 4'b1011) ? 4'b1010 :
        (q == 4'b1001) ? 4'b1011 : 4'b1001;

    assign next_gray_up =
        (q == 4'b0000) ? 4'b0001 :
        (q == 4'b0001) ? 4'b0011 :
        (q == 4'b0011) ? 4'b0010 :
        (q == 4'b0010) ? 4'b0110 :
        (q == 4'b0110) ? 4'b0111 :
        (q == 4'b0111) ? 4'b0101 :
        (q == 4'b0101) ? 4'b0100 :
        (q == 4'b0100) ? 4'b1100 :
        (q == 4'b1100) ? 4'b1101 :
        (q == 4'b1101) ? 4'b1111 :
        (q == 4'b1111) ? 4'b1110 :
        (q == 4'b1110) ? 4'b1010 :
        (q == 4'b1010) ? 4'b1011 :
        (q == 4'b1011) ? 4'b1001 :
        (q == 4'b1001) ? 4'b1000 : 4'b0000;

    assign next_state = (MODE == 0) ? next_aiken :
                        (MODE == 1) ? next_gray_down :
                        (dir ? next_gray_down : next_gray_up);
    assign t = q ^ next_state;

    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : make_t_ff
            t_ff bit_ff(clock, enable, t[i], q[i]);
        end
    endgenerate
endmodule


module counter_beh_case #(
    parameter integer MODE = 0
) (
    input wire clock,
    input wire enable,
    input wire dir,
    output wire [3:0] q
);
    reg [3:0] next_state;
    wire [3:0] t;

    always @(*) begin
        next_state = 4'b0000;
        if (MODE == 0) begin
            case (q)
                4'b0000: next_state = 4'b0001;
                4'b0001: next_state = 4'b0010;
                4'b0010: next_state = 4'b0011;
                4'b0011: next_state = 4'b0100;
                4'b0100: next_state = 4'b1011;
                4'b1011: next_state = 4'b1100;
                4'b1100: next_state = 4'b1101;
                4'b1101: next_state = 4'b1110;
                4'b1110: next_state = 4'b1111;
                4'b1111: next_state = 4'b0000;
                default: next_state = 4'b0000;
            endcase
        end else if ((MODE == 1) || dir) begin
            case (q)
                4'b0000: next_state = 4'b1000;
                4'b0001: next_state = 4'b0000;
                4'b0011: next_state = 4'b0001;
                4'b0010: next_state = 4'b0011;
                4'b0110: next_state = 4'b0010;
                4'b0111: next_state = 4'b0110;
                4'b0101: next_state = 4'b0111;
                4'b0100: next_state = 4'b0101;
                4'b1100: next_state = 4'b0100;
                4'b1101: next_state = 4'b1100;
                4'b1111: next_state = 4'b1101;
                4'b1110: next_state = 4'b1111;
                4'b1010: next_state = 4'b1110;
                4'b1011: next_state = 4'b1010;
                4'b1001: next_state = 4'b1011;
                4'b1000: next_state = 4'b1001;
                default: next_state = 4'b0000;
            endcase
        end else begin
            case (q)
                4'b0000: next_state = 4'b0001;
                4'b0001: next_state = 4'b0011;
                4'b0011: next_state = 4'b0010;
                4'b0010: next_state = 4'b0110;
                4'b0110: next_state = 4'b0111;
                4'b0111: next_state = 4'b0101;
                4'b0101: next_state = 4'b0100;
                4'b0100: next_state = 4'b1100;
                4'b1100: next_state = 4'b1101;
                4'b1101: next_state = 4'b1111;
                4'b1111: next_state = 4'b1110;
                4'b1110: next_state = 4'b1010;
                4'b1010: next_state = 4'b1011;
                4'b1011: next_state = 4'b1001;
                4'b1001: next_state = 4'b1000;
                4'b1000: next_state = 4'b0000;
                default: next_state = 4'b0000;
            endcase
        end
    end

    assign t = q ^ next_state;
    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : make_t_ff
            t_ff bit_ff(clock, enable, t[i], q[i]);
        end
    endgenerate
endmodule


module counter_beh_if #(
    parameter integer MODE = 0
) (
    input wire clock,
    input wire enable,
    input wire dir,
    output wire [3:0] q
);
    reg [3:0] next_state;
    wire [3:0] t;

    always @(*) begin
        next_state = 4'b0000;
        if (MODE == 0) begin
            if      (q == 4'b0000) next_state = 4'b0001;
            else if (q == 4'b0001) next_state = 4'b0010;
            else if (q == 4'b0010) next_state = 4'b0011;
            else if (q == 4'b0011) next_state = 4'b0100;
            else if (q == 4'b0100) next_state = 4'b1011;
            else if (q == 4'b1011) next_state = 4'b1100;
            else if (q == 4'b1100) next_state = 4'b1101;
            else if (q == 4'b1101) next_state = 4'b1110;
            else if (q == 4'b1110) next_state = 4'b1111;
            else if (q == 4'b1111) next_state = 4'b0000;
        end else if ((MODE == 1) || dir) begin
            if      (q == 4'b0000) next_state = 4'b1000;
            else if (q == 4'b1000) next_state = 4'b1001;
            else if (q == 4'b1001) next_state = 4'b1011;
            else if (q == 4'b1011) next_state = 4'b1010;
            else if (q == 4'b1010) next_state = 4'b1110;
            else if (q == 4'b1110) next_state = 4'b1111;
            else if (q == 4'b1111) next_state = 4'b1101;
            else if (q == 4'b1101) next_state = 4'b1100;
            else if (q == 4'b1100) next_state = 4'b0100;
            else if (q == 4'b0100) next_state = 4'b0101;
            else if (q == 4'b0101) next_state = 4'b0111;
            else if (q == 4'b0111) next_state = 4'b0110;
            else if (q == 4'b0110) next_state = 4'b0010;
            else if (q == 4'b0010) next_state = 4'b0011;
            else if (q == 4'b0011) next_state = 4'b0001;
            else if (q == 4'b0001) next_state = 4'b0000;
        end else begin
            if      (q == 4'b0000) next_state = 4'b0001;
            else if (q == 4'b0001) next_state = 4'b0011;
            else if (q == 4'b0011) next_state = 4'b0010;
            else if (q == 4'b0010) next_state = 4'b0110;
            else if (q == 4'b0110) next_state = 4'b0111;
            else if (q == 4'b0111) next_state = 4'b0101;
            else if (q == 4'b0101) next_state = 4'b0100;
            else if (q == 4'b0100) next_state = 4'b1100;
            else if (q == 4'b1100) next_state = 4'b1101;
            else if (q == 4'b1101) next_state = 4'b1111;
            else if (q == 4'b1111) next_state = 4'b1110;
            else if (q == 4'b1110) next_state = 4'b1010;
            else if (q == 4'b1010) next_state = 4'b1011;
            else if (q == 4'b1011) next_state = 4'b1001;
            else if (q == 4'b1001) next_state = 4'b1000;
            else if (q == 4'b1000) next_state = 4'b0000;
        end
    end

    assign t = q ^ next_state;
    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : make_t_ff
            t_ff bit_ff(clock, enable, t[i], q[i]);
        end
    endgenerate
endmodule


module counter_beh_function #(
    parameter integer MODE = 0
) (
    input wire clock,
    input wire enable,
    input wire dir,
    output wire [3:0] q
);
    wire [3:0] next_state;
    wire [3:0] t;

    function [3:0] next_aiken;
        input [3:0] state;
        begin
            case (state)
                4'h0: next_aiken = 4'h1;
                4'h1: next_aiken = 4'h2;
                4'h2: next_aiken = 4'h3;
                4'h3: next_aiken = 4'h4;
                4'h4: next_aiken = 4'hB;
                4'hB: next_aiken = 4'hC;
                4'hC: next_aiken = 4'hD;
                4'hD: next_aiken = 4'hE;
                4'hE: next_aiken = 4'hF;
                4'hF: next_aiken = 4'h0;
                default: next_aiken = 4'h0;
            endcase
        end
    endfunction

    function [3:0] next_gray_down;
        input [3:0] state;
        begin
            case (state)
                4'h0: next_gray_down = 4'h8;
                4'h8: next_gray_down = 4'h9;
                4'h9: next_gray_down = 4'hB;
                4'hB: next_gray_down = 4'hA;
                4'hA: next_gray_down = 4'hE;
                4'hE: next_gray_down = 4'hF;
                4'hF: next_gray_down = 4'hD;
                4'hD: next_gray_down = 4'hC;
                4'hC: next_gray_down = 4'h4;
                4'h4: next_gray_down = 4'h5;
                4'h5: next_gray_down = 4'h7;
                4'h7: next_gray_down = 4'h6;
                4'h6: next_gray_down = 4'h2;
                4'h2: next_gray_down = 4'h3;
                4'h3: next_gray_down = 4'h1;
                4'h1: next_gray_down = 4'h0;
                default: next_gray_down = 4'h0;
            endcase
        end
    endfunction

    function [3:0] next_gray_up;
        input [3:0] state;
        begin
            case (state)
                4'h0: next_gray_up = 4'h1;
                4'h1: next_gray_up = 4'h3;
                4'h3: next_gray_up = 4'h2;
                4'h2: next_gray_up = 4'h6;
                4'h6: next_gray_up = 4'h7;
                4'h7: next_gray_up = 4'h5;
                4'h5: next_gray_up = 4'h4;
                4'h4: next_gray_up = 4'hC;
                4'hC: next_gray_up = 4'hD;
                4'hD: next_gray_up = 4'hF;
                4'hF: next_gray_up = 4'hE;
                4'hE: next_gray_up = 4'hA;
                4'hA: next_gray_up = 4'hB;
                4'hB: next_gray_up = 4'h9;
                4'h9: next_gray_up = 4'h8;
                4'h8: next_gray_up = 4'h0;
                default: next_gray_up = 4'h0;
            endcase
        end
    endfunction

    assign next_state = (MODE == 0) ? next_aiken(q) :
                        (MODE == 1) ? next_gray_down(q) :
                        (dir ? next_gray_down(q) : next_gray_up(q));
    assign t = q ^ next_state;

    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : make_t_ff
            t_ff bit_ff(clock, enable, t[i], q[i]);
        end
    endgenerate
endmodule
